from core import Program

def main():
    app = Program.Program()
    app.start()

if __name__ == "__main__":
    main()
